﻿/**
* 06FEB22
* CSC 153
* Taylor J. Brown
* This program compares a given array of answers to an answer key and displays the results
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class DriversLicenseExam : Form
    {
        // collects the correct and incorrect counts
        int correct = 0;
        int incorrect = 0;

        // Stores index + 1 to get the question number that was incorrect
        List<int> storedIncorrect = new List<int>();

        // Stored correct answers for the exam
        string[] examAnswers = { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
 
        // This is the Pass example:
        string[] studentAnswers = { "B", "B", "A", "A", "C", "A", "A", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "A", "D", "B" };

        // This is the Fail example:
        //string[] studentAnswers = { "B", "B", "A", "A", "C", "A", "B", "C", "C", "D", "B", "A", "D", "A", "B", "A", "C", "A", "C", "B" };


        public DriversLicenseExam()
        {
            InitializeComponent();
        }


        private void DriversLicenseExam_Load(object sender, EventArgs e)
        {
            // Iterates through the arrays and checks each value
            for (int index = 0; index < examAnswers.Length; index++){
                if (examAnswers[index] == studentAnswers[index]){
                    correct++;
                }else{
                    incorrect++;
                    storedIncorrect.Add(index + 1);
                }
            }

            // Displays "Passed" if the user got >15 or "Failed" if the user got <15
            if (correct >= 15){
                PFLabel.Text = "Passed";
            }else{
                PFLabel.Text = "Failed";
            }

            // Displays the correct and incorrect numbers
            correctLabel.Text = correct.ToString();
            incorrectLabel.Text = incorrect.ToString();

            // Displays the incorrect answered questions
            foreach (int question in storedIncorrect) {
                incorrectAnswersList.Items.Add(question.ToString());
            }
        }
    }
}
