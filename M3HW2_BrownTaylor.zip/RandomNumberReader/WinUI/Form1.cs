﻿/**
* 22FEB22
* CSC 153
* Taylor J. Brown
* This program opens a file and displays what the sum of all the numbers 
* is and how many numbers there where in the file.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    public partial class RandomNumberReader : Form
    {
        public RandomNumberReader()
        {
            InitializeComponent();
        }

        private void openFile_Click(object sender, EventArgs e)
        {
            // Holds all numbers from a file
            List<int> numbers = new List<int>();

            // Opens the file that the user chooses 
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.Title  = "Open a Text File";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream stream = File.Open(openFileDialog1.FileName, FileMode.Open))
                using (StreamReader inputFile = new StreamReader(stream))
                {
                    try 
                    { 
                        // Adds each line of the file into a list
                        while (inputFile.EndOfStream == false)
                        {
                            numbers.Add(Convert.ToInt32(inputFile.ReadLine()));
                        }
                        inputFile.Close();

                        // Clears the listBox incase another file was opened
                        listBoxNumbers.Items.Clear();

                        /* 
                           Adds each number to the listBox and calculates
                           the total of all numbers in the opened file.
                        */
                        int total = 0;
                        foreach (int number in numbers)
                        {
                            listBoxNumbers.Items.Add(number);
                            total += number;
                        }

                        // Updates the sum and count labels
                        labelSum.Text = total.ToString();
                        labelContentTotal.Text = numbers.Count().ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Incorrect file");
                    }

                }
            }
        }
    }
}
