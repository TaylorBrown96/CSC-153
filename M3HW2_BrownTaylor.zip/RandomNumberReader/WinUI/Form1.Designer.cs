﻿namespace WinUI
{
    partial class RandomNumberReader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelShowContents = new System.Windows.Forms.Label();
            this.openFile = new System.Windows.Forms.Button();
            this.listBoxNumbers = new System.Windows.Forms.ListBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelContents = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelSum = new System.Windows.Forms.Label();
            this.labelContentTotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelShowContents
            // 
            this.labelShowContents.AutoSize = true;
            this.labelShowContents.Location = new System.Drawing.Point(73, 75);
            this.labelShowContents.Name = "labelShowContents";
            this.labelShowContents.Size = new System.Drawing.Size(137, 13);
            this.labelShowContents.TabIndex = 0;
            this.labelShowContents.Text = "Contents of the opened file:";
            // 
            // openFile
            // 
            this.openFile.Location = new System.Drawing.Point(76, 12);
            this.openFile.Name = "openFile";
            this.openFile.Size = new System.Drawing.Size(153, 41);
            this.openFile.TabIndex = 1;
            this.openFile.Text = "Open a file";
            this.openFile.UseVisualStyleBackColor = true;
            this.openFile.Click += new System.EventHandler(this.openFile_Click);
            // 
            // listBoxNumbers
            // 
            this.listBoxNumbers.FormattingEnabled = true;
            this.listBoxNumbers.Location = new System.Drawing.Point(76, 91);
            this.listBoxNumbers.Name = "listBoxNumbers";
            this.listBoxNumbers.Size = new System.Drawing.Size(153, 121);
            this.listBoxNumbers.TabIndex = 2;
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(73, 224);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(132, 13);
            this.labelTotal.TabIndex = 3;
            this.labelTotal.Text = "Total of all numbers in file: ";
            // 
            // labelContents
            // 
            this.labelContents.AutoSize = true;
            this.labelContents.Location = new System.Drawing.Point(73, 262);
            this.labelContents.Name = "labelContents";
            this.labelContents.Size = new System.Drawing.Size(132, 13);
            this.labelContents.TabIndex = 4;
            this.labelContents.Text = "Number of numbers in file: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(153, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 5;
            // 
            // labelSum
            // 
            this.labelSum.AutoSize = true;
            this.labelSum.BackColor = System.Drawing.SystemColors.Control;
            this.labelSum.Location = new System.Drawing.Point(211, 224);
            this.labelSum.Name = "labelSum";
            this.labelSum.Size = new System.Drawing.Size(13, 13);
            this.labelSum.TabIndex = 6;
            this.labelSum.Text = "0";
            // 
            // labelContentTotal
            // 
            this.labelContentTotal.AutoSize = true;
            this.labelContentTotal.Location = new System.Drawing.Point(211, 262);
            this.labelContentTotal.Name = "labelContentTotal";
            this.labelContentTotal.Size = new System.Drawing.Size(13, 13);
            this.labelContentTotal.TabIndex = 7;
            this.labelContentTotal.Text = "0";
            // 
            // RandomNumberReader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 297);
            this.Controls.Add(this.labelContentTotal);
            this.Controls.Add(this.labelSum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelContents);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.listBoxNumbers);
            this.Controls.Add(this.openFile);
            this.Controls.Add(this.labelShowContents);
            this.Name = "RandomNumberReader";
            this.Text = "RandomNumberReader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelShowContents;
        private System.Windows.Forms.Button openFile;
        private System.Windows.Forms.ListBox listBoxNumbers;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label labelContents;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelSum;
        private System.Windows.Forms.Label labelContentTotal;
    }
}

