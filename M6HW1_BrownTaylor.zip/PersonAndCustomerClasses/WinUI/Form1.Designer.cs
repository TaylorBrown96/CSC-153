﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_nameInput = new System.Windows.Forms.TextBox();
            this.TB_addressInput = new System.Windows.Forms.TextBox();
            this.TB_phoneNumberInput = new System.Windows.Forms.TextBox();
            this.TB_customerNumberInput = new System.Windows.Forms.TextBox();
            this.TB_customerNumberOutput = new System.Windows.Forms.TextBox();
            this.TB_phoneOutput = new System.Windows.Forms.TextBox();
            this.TB_addressOutput = new System.Windows.Forms.TextBox();
            this.TB_nameOutput = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TB_mailingListOutput = new System.Windows.Forms.TextBox();
            this.BT_Create = new System.Windows.Forms.Button();
            this.BT_Exit = new System.Windows.Forms.Button();
            this.CB_Agree = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Customer Data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(99, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(96, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone #:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(83, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Customer #:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(85, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Mailing List:";
            // 
            // TB_nameInput
            // 
            this.TB_nameInput.Location = new System.Drawing.Point(153, 28);
            this.TB_nameInput.Name = "TB_nameInput";
            this.TB_nameInput.Size = new System.Drawing.Size(100, 20);
            this.TB_nameInput.TabIndex = 0;
            // 
            // TB_addressInput
            // 
            this.TB_addressInput.Location = new System.Drawing.Point(153, 54);
            this.TB_addressInput.Name = "TB_addressInput";
            this.TB_addressInput.Size = new System.Drawing.Size(100, 20);
            this.TB_addressInput.TabIndex = 1;
            // 
            // TB_phoneNumberInput
            // 
            this.TB_phoneNumberInput.Location = new System.Drawing.Point(153, 80);
            this.TB_phoneNumberInput.Name = "TB_phoneNumberInput";
            this.TB_phoneNumberInput.Size = new System.Drawing.Size(100, 20);
            this.TB_phoneNumberInput.TabIndex = 2;
            // 
            // TB_customerNumberInput
            // 
            this.TB_customerNumberInput.Location = new System.Drawing.Point(153, 106);
            this.TB_customerNumberInput.Name = "TB_customerNumberInput";
            this.TB_customerNumberInput.ReadOnly = true;
            this.TB_customerNumberInput.Size = new System.Drawing.Size(100, 20);
            this.TB_customerNumberInput.TabIndex = 9;
            this.TB_customerNumberInput.TabStop = false;
            // 
            // TB_customerNumberOutput
            // 
            this.TB_customerNumberOutput.Location = new System.Drawing.Point(153, 281);
            this.TB_customerNumberOutput.Name = "TB_customerNumberOutput";
            this.TB_customerNumberOutput.ReadOnly = true;
            this.TB_customerNumberOutput.Size = new System.Drawing.Size(100, 20);
            this.TB_customerNumberOutput.TabIndex = 20;
            this.TB_customerNumberOutput.TabStop = false;
            // 
            // TB_phoneOutput
            // 
            this.TB_phoneOutput.Location = new System.Drawing.Point(153, 255);
            this.TB_phoneOutput.Name = "TB_phoneOutput";
            this.TB_phoneOutput.ReadOnly = true;
            this.TB_phoneOutput.Size = new System.Drawing.Size(100, 20);
            this.TB_phoneOutput.TabIndex = 19;
            this.TB_phoneOutput.TabStop = false;
            // 
            // TB_addressOutput
            // 
            this.TB_addressOutput.Location = new System.Drawing.Point(153, 229);
            this.TB_addressOutput.Name = "TB_addressOutput";
            this.TB_addressOutput.ReadOnly = true;
            this.TB_addressOutput.Size = new System.Drawing.Size(100, 20);
            this.TB_addressOutput.TabIndex = 18;
            this.TB_addressOutput.TabStop = false;
            // 
            // TB_nameOutput
            // 
            this.TB_nameOutput.Location = new System.Drawing.Point(153, 203);
            this.TB_nameOutput.Name = "TB_nameOutput";
            this.TB_nameOutput.ReadOnly = true;
            this.TB_nameOutput.Size = new System.Drawing.Size(100, 20);
            this.TB_nameOutput.TabIndex = 17;
            this.TB_nameOutput.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(85, 316);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Mailing List:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(83, 288);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Customer #:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(96, 262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Phone #:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 236);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(109, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(69, 182);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Object Properties";
            // 
            // TB_mailingListOutput
            // 
            this.TB_mailingListOutput.Location = new System.Drawing.Point(153, 309);
            this.TB_mailingListOutput.Name = "TB_mailingListOutput";
            this.TB_mailingListOutput.ReadOnly = true;
            this.TB_mailingListOutput.Size = new System.Drawing.Size(100, 20);
            this.TB_mailingListOutput.TabIndex = 21;
            this.TB_mailingListOutput.TabStop = false;
            // 
            // BT_Create
            // 
            this.BT_Create.Location = new System.Drawing.Point(72, 363);
            this.BT_Create.Name = "BT_Create";
            this.BT_Create.Size = new System.Drawing.Size(75, 40);
            this.BT_Create.TabIndex = 3;
            this.BT_Create.Text = "Create Customer";
            this.BT_Create.UseVisualStyleBackColor = true;
            this.BT_Create.Click += new System.EventHandler(this.BT_Create_Click);
            // 
            // BT_Exit
            // 
            this.BT_Exit.Location = new System.Drawing.Point(178, 363);
            this.BT_Exit.Name = "BT_Exit";
            this.BT_Exit.Size = new System.Drawing.Size(75, 40);
            this.BT_Exit.TabIndex = 23;
            this.BT_Exit.TabStop = false;
            this.BT_Exit.Text = "Exit";
            this.BT_Exit.UseVisualStyleBackColor = true;
            this.BT_Exit.Click += new System.EventHandler(this.BT_Exit_Click);
            // 
            // CB_Agree
            // 
            this.CB_Agree.AutoSize = true;
            this.CB_Agree.Location = new System.Drawing.Point(153, 134);
            this.CB_Agree.Name = "CB_Agree";
            this.CB_Agree.Size = new System.Drawing.Size(54, 17);
            this.CB_Agree.TabIndex = 7;
            this.CB_Agree.TabStop = false;
            this.CB_Agree.Text = "Agree";
            this.CB_Agree.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 424);
            this.Controls.Add(this.CB_Agree);
            this.Controls.Add(this.BT_Exit);
            this.Controls.Add(this.BT_Create);
            this.Controls.Add(this.TB_mailingListOutput);
            this.Controls.Add(this.TB_customerNumberOutput);
            this.Controls.Add(this.TB_phoneOutput);
            this.Controls.Add(this.TB_addressOutput);
            this.Controls.Add(this.TB_nameOutput);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.TB_customerNumberInput);
            this.Controls.Add(this.TB_phoneNumberInput);
            this.Controls.Add(this.TB_addressInput);
            this.Controls.Add(this.TB_nameInput);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "PersonAndCustomerClasses";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_nameInput;
        private System.Windows.Forms.TextBox TB_addressInput;
        private System.Windows.Forms.TextBox TB_phoneNumberInput;
        private System.Windows.Forms.TextBox TB_customerNumberInput;
        private System.Windows.Forms.TextBox TB_customerNumberOutput;
        private System.Windows.Forms.TextBox TB_phoneOutput;
        private System.Windows.Forms.TextBox TB_addressOutput;
        private System.Windows.Forms.TextBox TB_nameOutput;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TB_mailingListOutput;
        private System.Windows.Forms.Button BT_Create;
        private System.Windows.Forms.Button BT_Exit;
        private System.Windows.Forms.CheckBox CB_Agree;
    }
}

