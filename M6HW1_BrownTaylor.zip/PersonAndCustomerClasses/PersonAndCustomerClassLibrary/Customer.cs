﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassLibrary
{
    // Inherits the name address and phone number from the parent class person
    public class Customer : Person 
    {
        public Customer(string name, string address, string phoneNumber, int customerNumber, bool mailingList) : base(name, address, phoneNumber)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            CustomerNumber = customerNumber;
            MailingList = mailingList;
        }

        public int CustomerNumber { get; set; }
        public bool MailingList { get; set; }
    }
}
