﻿/**
* 07MAR22
* CSC 153
* Taylor J. Brown
* This program takes in how many seconds an object fell and displays the distance
*   the object fell in meters.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingDistanceLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Updates the PictureBox to show the screen capture of the Formula
            Image file = Image.FromFile("Formula.PNG");
            PB_Formula.Image = file;
        }

        private void B_Calculate_Click(object sender, EventArgs e)
        {
            double seconds = 0.0;
            // Takes in user input and converts the string to a double.
            try
            {
                seconds = Convert.ToDouble(TB_SecondsObjFell.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Please enter a valid number!");
            }
            
            // Sends the seconds variable to the Falling Distance method in the Calculate class.
            double distance = Calculate.FallingDistance(seconds);

            // Updates the textbox to display the distance the object fell.
            TB_DistanceObjFell.Text = (Convert.ToString(distance));
        }
    }
}
