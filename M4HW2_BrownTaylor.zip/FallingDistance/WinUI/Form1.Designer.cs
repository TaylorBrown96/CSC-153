﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B_Calculate = new System.Windows.Forms.Button();
            this.L_Question = new System.Windows.Forms.Label();
            this.TB_SecondsObjFell = new System.Windows.Forms.TextBox();
            this.TB_DistanceObjFell = new System.Windows.Forms.TextBox();
            this.L_Results = new System.Windows.Forms.Label();
            this.L_DistanceMesurement = new System.Windows.Forms.Label();
            this.L_PreferedDataType = new System.Windows.Forms.Label();
            this.PB_Formula = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Formula)).BeginInit();
            this.SuspendLayout();
            // 
            // B_Calculate
            // 
            this.B_Calculate.Location = new System.Drawing.Point(15, 52);
            this.B_Calculate.Name = "B_Calculate";
            this.B_Calculate.Size = new System.Drawing.Size(75, 23);
            this.B_Calculate.TabIndex = 0;
            this.B_Calculate.Text = "Calculate";
            this.B_Calculate.UseVisualStyleBackColor = true;
            this.B_Calculate.Click += new System.EventHandler(this.B_Calculate_Click);
            // 
            // L_Question
            // 
            this.L_Question.AutoSize = true;
            this.L_Question.Location = new System.Drawing.Point(12, 9);
            this.L_Question.Name = "L_Question";
            this.L_Question.Size = new System.Drawing.Size(156, 13);
            this.L_Question.TabIndex = 1;
            this.L_Question.Text = "How long did the object fall for?";
            // 
            // TB_SecondsObjFell
            // 
            this.TB_SecondsObjFell.Location = new System.Drawing.Point(15, 26);
            this.TB_SecondsObjFell.Name = "TB_SecondsObjFell";
            this.TB_SecondsObjFell.Size = new System.Drawing.Size(100, 20);
            this.TB_SecondsObjFell.TabIndex = 2;
            // 
            // TB_DistanceObjFell
            // 
            this.TB_DistanceObjFell.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TB_DistanceObjFell.Location = new System.Drawing.Point(-1, 125);
            this.TB_DistanceObjFell.Name = "TB_DistanceObjFell";
            this.TB_DistanceObjFell.ReadOnly = true;
            this.TB_DistanceObjFell.Size = new System.Drawing.Size(75, 13);
            this.TB_DistanceObjFell.TabIndex = 3;
            this.TB_DistanceObjFell.TabStop = false;
            this.TB_DistanceObjFell.Text = "0";
            this.TB_DistanceObjFell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // L_Results
            // 
            this.L_Results.AutoSize = true;
            this.L_Results.Location = new System.Drawing.Point(12, 105);
            this.L_Results.Name = "L_Results";
            this.L_Results.Size = new System.Drawing.Size(144, 13);
            this.L_Results.TabIndex = 4;
            this.L_Results.Text = "The object fell a distance of :";
            // 
            // L_DistanceMesurement
            // 
            this.L_DistanceMesurement.AutoSize = true;
            this.L_DistanceMesurement.Location = new System.Drawing.Point(74, 125);
            this.L_DistanceMesurement.Name = "L_DistanceMesurement";
            this.L_DistanceMesurement.Size = new System.Drawing.Size(39, 13);
            this.L_DistanceMesurement.TabIndex = 5;
            this.L_DistanceMesurement.Text = "Meters";
            // 
            // L_PreferedDataType
            // 
            this.L_PreferedDataType.AutoSize = true;
            this.L_PreferedDataType.Location = new System.Drawing.Point(115, 29);
            this.L_PreferedDataType.Name = "L_PreferedDataType";
            this.L_PreferedDataType.Size = new System.Drawing.Size(70, 13);
            this.L_PreferedDataType.TabIndex = 6;
            this.L_PreferedDataType.Text = "( in seconds )";
            // 
            // PB_Formula
            // 
            this.PB_Formula.Location = new System.Drawing.Point(193, 76);
            this.PB_Formula.Name = "PB_Formula";
            this.PB_Formula.Size = new System.Drawing.Size(90, 51);
            this.PB_Formula.TabIndex = 7;
            this.PB_Formula.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(180, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Falling distance formula:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 150);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PB_Formula);
            this.Controls.Add(this.L_PreferedDataType);
            this.Controls.Add(this.L_DistanceMesurement);
            this.Controls.Add(this.L_Results);
            this.Controls.Add(this.TB_DistanceObjFell);
            this.Controls.Add(this.TB_SecondsObjFell);
            this.Controls.Add(this.L_Question);
            this.Controls.Add(this.B_Calculate);
            this.Name = "Form1";
            this.Text = "FallingDistance";
            ((System.ComponentModel.ISupportInitialize)(this.PB_Formula)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_Calculate;
        private System.Windows.Forms.Label L_Question;
        private System.Windows.Forms.TextBox TB_SecondsObjFell;
        private System.Windows.Forms.TextBox TB_DistanceObjFell;
        private System.Windows.Forms.Label L_Results;
        private System.Windows.Forms.Label L_DistanceMesurement;
        private System.Windows.Forms.Label L_PreferedDataType;
        private System.Windows.Forms.PictureBox PB_Formula;
        private System.Windows.Forms.Label label1;
    }
}

