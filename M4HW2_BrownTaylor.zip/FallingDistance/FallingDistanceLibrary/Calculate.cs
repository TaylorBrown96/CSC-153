﻿/**
* 07MAR22
* CSC 153
* Taylor J. Brown
* This class takes in an argument seconds as a double and returns distance as a double
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingDistanceLibrary
{
    public static class Calculate
    {
        public static double FallingDistance(double seconds)
        {
            /*
             * Firstly Declare the constant gravity for earth (9.8m/s^2)
             * 
             * Then take in the amount of time the object fell as an 
             * argument and substitute g for gravity and t for seconds
             * and multiply by 0.5 to get the distance
             * 
             * Lastly return the distance 
             */

            const double GRAVITY_EARTH = 9.8;

            double distance = seconds * seconds * GRAVITY_EARTH * 0.5;

            return distance;
        }

    }
}
