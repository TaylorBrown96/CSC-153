﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace WinUI
{
    public partial class EditEmployees : Form
    {
        // Stores the users choice incase they want to edit the name 
        public static int employeeIndex = -1;

        public EditEmployees()
        {
            InitializeComponent();

            // Resets the employee index if the user tries the same error multiple times
            employeeIndex = -1;

            // Populates the combo box so the user can select which employee they want to change
            for (int i = 0; i < Employee.Employees.Count; i++)
            {
                CB_Employees.Items.Add(Employee.Employees[i].Name);
            }
        }

        private void CB_Employees_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Gets the index of the selected employee and sets the global index for that change
            employeeIndex = Employee.Employees.FindIndex(a => a.Name == CB_Employees.SelectedItem.ToString());

            // Fills in the text boxes so they can be edited
            TB_IDNumberEDIT.Text = Convert.ToString(Employee.Employees[employeeIndex].IDNumber);
            TB_DepartmentEDIT.Text = Employee.Employees[employeeIndex].Department;
            TB_PositionEDIT.Text = Employee.Employees[employeeIndex].Position;
        }

        private void Btn_Submit_Click(object sender, EventArgs e)
        {

            // Gets the Employee's name
            string Name;
            if (CB_Employees.Text.Length == 0)
            {
                MessageBox.Show("Please make a selection.", "Error!");
                return;
            }
            else if (employeeIndex == -1)
            {
                MessageBox.Show("Employee doesn't exist yet", "Error!");
                return;
            }
            else
            {
                Name = CB_Employees.Text;
            }
            

            // Gets the Employee's IDNumber and trys to convert it to an int
            int IDNumber;
            try
            {
                IDNumber = Convert.ToInt32(TB_IDNumberEDIT.Text);
            }
            catch (Exception)
            {
                // Displays message box and cancels the process
                MessageBox.Show("Please enter a valid Integer for your employees ID#!", "Error!");
                return;
            }

            // Gets the Employee's Department
            string Department = TB_DepartmentEDIT.Text;

            // Gets the Employee's Position
            string Position = TB_PositionEDIT.Text;

            // Changes the properties of the selected object
            Employee.Employees[employeeIndex].Name = Name;
            Employee.Employees[employeeIndex].IDNumber = IDNumber;
            Employee.Employees[employeeIndex].Department = Department;
            Employee.Employees[employeeIndex].Position = Position;

            // Closes the form
            Close();
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            // Deletes the selected employee
            if (CB_Employees.Text.Length == 0)
            {
                MessageBox.Show("Please make a selection.", "Error!");
                return;
            }
            else
            {
                Employee.Employees.RemoveAt(employeeIndex);
            }

            // Closes the form 
            Close();
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            // Closes the form
            Close();
        }
    }
}
