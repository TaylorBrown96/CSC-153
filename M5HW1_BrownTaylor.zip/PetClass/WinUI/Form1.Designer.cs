﻿namespace WinUI
{
    partial class Form_PetClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.L_Name = new System.Windows.Forms.Label();
            this.CB_Type = new System.Windows.Forms.ComboBox();
            this.L_Type = new System.Windows.Forms.Label();
            this.TB_Age = new System.Windows.Forms.TextBox();
            this.L_Age = new System.Windows.Forms.Label();
            this.LB_Names = new System.Windows.Forms.ListBox();
            this.L_Names = new System.Windows.Forms.Label();
            this.B_AddPet = new System.Windows.Forms.Button();
            this.LB_Types = new System.Windows.Forms.ListBox();
            this.LB_Ages = new System.Windows.Forms.ListBox();
            this.L_Types = new System.Windows.Forms.Label();
            this.L_Ages = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(12, 25);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(100, 20);
            this.TB_Name.TabIndex = 0;
            // 
            // L_Name
            // 
            this.L_Name.AutoSize = true;
            this.L_Name.Location = new System.Drawing.Point(12, 9);
            this.L_Name.Name = "L_Name";
            this.L_Name.Size = new System.Drawing.Size(60, 13);
            this.L_Name.TabIndex = 1;
            this.L_Name.Text = "Pets name:";
            // 
            // CB_Type
            // 
            this.CB_Type.FormattingEnabled = true;
            this.CB_Type.Items.AddRange(new object[] {
            "Dog",
            "Cat",
            "Bird",
            "Lizard",
            "Bunny",
            "Snake"});
            this.CB_Type.Location = new System.Drawing.Point(12, 67);
            this.CB_Type.Name = "CB_Type";
            this.CB_Type.Size = new System.Drawing.Size(100, 21);
            this.CB_Type.TabIndex = 2;
            // 
            // L_Type
            // 
            this.L_Type.AutoSize = true;
            this.L_Type.Location = new System.Drawing.Point(12, 48);
            this.L_Type.Name = "L_Type";
            this.L_Type.Size = new System.Drawing.Size(64, 13);
            this.L_Type.TabIndex = 3;
            this.L_Type.Text = "Type of pet:";
            // 
            // TB_Age
            // 
            this.TB_Age.Location = new System.Drawing.Point(12, 110);
            this.TB_Age.Name = "TB_Age";
            this.TB_Age.Size = new System.Drawing.Size(100, 20);
            this.TB_Age.TabIndex = 4;
            // 
            // L_Age
            // 
            this.L_Age.AutoSize = true;
            this.L_Age.Location = new System.Drawing.Point(12, 91);
            this.L_Age.Name = "L_Age";
            this.L_Age.Size = new System.Drawing.Size(59, 13);
            this.L_Age.TabIndex = 5;
            this.L_Age.Text = "Age of pet:";
            // 
            // LB_Names
            // 
            this.LB_Names.FormattingEnabled = true;
            this.LB_Names.Location = new System.Drawing.Point(144, 25);
            this.LB_Names.Name = "LB_Names";
            this.LB_Names.Size = new System.Drawing.Size(64, 134);
            this.LB_Names.TabIndex = 6;
            // 
            // L_Names
            // 
            this.L_Names.AutoSize = true;
            this.L_Names.Location = new System.Drawing.Point(141, 9);
            this.L_Names.Name = "L_Names";
            this.L_Names.Size = new System.Drawing.Size(43, 13);
            this.L_Names.TabIndex = 7;
            this.L_Names.Text = "Names:";
            // 
            // B_AddPet
            // 
            this.B_AddPet.Location = new System.Drawing.Point(12, 136);
            this.B_AddPet.Name = "B_AddPet";
            this.B_AddPet.Size = new System.Drawing.Size(100, 23);
            this.B_AddPet.TabIndex = 8;
            this.B_AddPet.Text = "Add";
            this.B_AddPet.UseVisualStyleBackColor = true;
            this.B_AddPet.Click += new System.EventHandler(this.B_AddPet_Click);
            // 
            // LB_Types
            // 
            this.LB_Types.FormattingEnabled = true;
            this.LB_Types.Location = new System.Drawing.Point(214, 25);
            this.LB_Types.Name = "LB_Types";
            this.LB_Types.Size = new System.Drawing.Size(64, 134);
            this.LB_Types.TabIndex = 9;
            // 
            // LB_Ages
            // 
            this.LB_Ages.FormattingEnabled = true;
            this.LB_Ages.Location = new System.Drawing.Point(284, 25);
            this.LB_Ages.Name = "LB_Ages";
            this.LB_Ages.Size = new System.Drawing.Size(64, 134);
            this.LB_Ages.TabIndex = 10;
            // 
            // L_Types
            // 
            this.L_Types.AutoSize = true;
            this.L_Types.Location = new System.Drawing.Point(211, 9);
            this.L_Types.Name = "L_Types";
            this.L_Types.Size = new System.Drawing.Size(39, 13);
            this.L_Types.TabIndex = 11;
            this.L_Types.Text = "Types:";
            // 
            // L_Ages
            // 
            this.L_Ages.AutoSize = true;
            this.L_Ages.Location = new System.Drawing.Point(281, 9);
            this.L_Ages.Name = "L_Ages";
            this.L_Ages.Size = new System.Drawing.Size(34, 13);
            this.L_Ages.TabIndex = 12;
            this.L_Ages.Text = "Ages:";
            // 
            // Form_PetClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 169);
            this.Controls.Add(this.L_Ages);
            this.Controls.Add(this.L_Types);
            this.Controls.Add(this.LB_Ages);
            this.Controls.Add(this.LB_Types);
            this.Controls.Add(this.B_AddPet);
            this.Controls.Add(this.L_Names);
            this.Controls.Add(this.LB_Names);
            this.Controls.Add(this.L_Age);
            this.Controls.Add(this.TB_Age);
            this.Controls.Add(this.L_Type);
            this.Controls.Add(this.CB_Type);
            this.Controls.Add(this.L_Name);
            this.Controls.Add(this.TB_Name);
            this.Name = "Form_PetClass";
            this.Text = "PetClass";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.Label L_Name;
        private System.Windows.Forms.ComboBox CB_Type;
        private System.Windows.Forms.Label L_Type;
        private System.Windows.Forms.TextBox TB_Age;
        private System.Windows.Forms.Label L_Age;
        private System.Windows.Forms.ListBox LB_Names;
        private System.Windows.Forms.Label L_Names;
        private System.Windows.Forms.Button B_AddPet;
        private System.Windows.Forms.ListBox LB_Types;
        private System.Windows.Forms.ListBox LB_Ages;
        private System.Windows.Forms.Label L_Types;
        private System.Windows.Forms.Label L_Ages;
    }
}

