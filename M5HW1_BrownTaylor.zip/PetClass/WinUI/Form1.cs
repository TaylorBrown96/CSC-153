﻿/**
* 27MAR22
* CSC 153
* Taylor J. Brown
* This program takes in a pets name, type, and age and creates an object 
* from that information and finally adds each object component into listboxes. 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

namespace WinUI
{
    public partial class Form_PetClass : Form
    {
        public Form_PetClass()
        {
            InitializeComponent();
        }

        private void B_AddPet_Click(object sender, EventArgs e)
        {
            // Default object for the constructor
            Pet pet = new Pet();


            /*
             * Name 
            */
            // Checks to see if the field was filled out
            if (TB_Name.Text.Length == 0)
            {
                MessageBox.Show("You forgot to fill in the name field!", "Error!");
                return;
            }
            else
            {
                // Gets the name and sets the objects name
                pet.Name = TB_Name.Text;
            }


            /*
             * Type 
            */
            // Checks to see if the field was filled out
            if (CB_Type.Text.Length == 0)
            {
                MessageBox.Show("You forgot to fill in the type field!", "Error!");
                return;
            }
            else
            {
                // Gets the type and sets the objects type
                pet.Type = CB_Type.Text;
            }


            /*
             * Age
            */
            try
            {
                // Checks to see if the field was filled out
                if (TB_Age.Text.Length == 0)
                {
                    MessageBox.Show("You forgot to fill in the age field!", "Error!");
                    return;
                }
                else
                {
                    // Gets the age and sets the objects age
                    pet.Age = Convert.ToInt32(TB_Age.Text);

                    // Adds each object property to their respective ListBoxes
                    LB_Names.Items.Add(pet.Name);
                    LB_Types.Items.Add(pet.Type);
                    LB_Ages.Items.Add(pet.Age);

                    // Clears the input fields to make multiple submitions easier
                    TB_Name.Text = "";
                    CB_Type.Text = "";
                    TB_Age.Text = "";
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid Integer for your pets age!", "Error!");
            }
        }
    }
}
