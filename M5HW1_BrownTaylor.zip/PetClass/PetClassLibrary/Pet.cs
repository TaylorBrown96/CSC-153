﻿/**
* 27MAR22
* CSC 153
* Taylor J. Brown
* This program takes in a pets name, type, and age and creates an object 
* from that information and finally adds each object component into listboxes. 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetClassLibrary
{
    public class Pet
    {
        // Fields for the pet’s name
        private string _name;
        private string _type;
        private int _age;

        // Constructor
        public Pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Type property
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        // Age property
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}
