﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class TotalSalesHardCoded : Form
    {
        // This is the array creation that takes in all values
        decimal[] sales = { 1245.67m, 1189.55m, 1098.72m, 1456.88m, 2109.34m, 1987.55m, 1872.36m };

        decimal total = 0.00m;
        public TotalSalesHardCoded()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (decimal sale in sales)
            {
                salesListbox.Items.Add(sale.ToString("C"));
                total += sale;
            }
            totalTextbox.Text = total.ToString("C");
        }
    }
}