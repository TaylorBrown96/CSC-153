﻿/**
* 29JAN22
* CSC 153
* Taylor J. Brown
* M2HW1_BrownTaylor | This program has a hard coded array of sales.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // This is the array creation that takes in all values
            decimal[] sales = { 1245.67m, 1189.55m, 1098.72m, 1456.88m, 2109.34m, 1987.55m, 1872.36m };



            // This prints out all sales that where hard coded
            Console.WriteLine("All the sales hard-coded:");
            for (int index = 0; index < sales.Length; index++)
            {
                Console.WriteLine(sales[index].ToString("C"));
            };

            // This adds the total of all sales together
            decimal totalSales = 0.00m;
            for (int index = 0; index < sales.Length; index++)
            {
                totalSales += sales[index];
            };

            // Displays the total
            Console.WriteLine($"\nThis is the total of all sales: {totalSales.ToString("C")}");
            
            // Waits for input from keyboard before closing
            Console.ReadKey();
        }
    }
}

// This is for quick reference
/**
    * 1245.67
    * 1189.55
    * 1098.72
    * 1456.88
    * 2109.34
    * 1987.55
    * 1872.36
*/