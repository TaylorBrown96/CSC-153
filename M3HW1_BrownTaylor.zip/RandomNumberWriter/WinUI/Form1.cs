﻿/**
* 19FEB22
* CSC 153
* Taylor J. Brown
* This program creates/writes a file that contains randomly generated numbers
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    public partial class Form1 : Form
    {
        // Holds randomly generated numbers
        List<string> randNums = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }


        private void btnEnter_Click(object sender, EventArgs e)
        {
            // trys to get user input
            int userInp = 0;
            try
            {
                userInp = int.Parse(textUserInp.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Please enter a number!");
            }

            // Generates random numbers based on the users input
            Random rand = new Random();
            for (int index = 0; index < userInp; index++)
            {
                randNums.Add(Convert.ToString(rand.Next(1, 101)));
            }

            // Writes each generated number in the listbox
            foreach (string str in randNums)
            {
                listGenerated.Items.Add(str);
            }
        }


        // Creates a .txt file with whatever name and place the user chooses
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.Title = "Save a Text File";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream stream = File.Open(saveFileDialog1.FileName, FileMode.CreateNew))
                using (StreamWriter streamWriter = new StreamWriter(stream))
                {
                    // Writes each randomly generated number to a line in the .txt file
                    foreach (string str in randNums)
                    {
                        streamWriter.WriteLine(str);
                    }
                }
            }
        }


        // Clears the listbox and clears the list of generated nums 
        private void btnClear_Click(object sender, EventArgs e)
        {
            listGenerated.Items.Clear();
            randNums.Clear();
        }

    }
}
