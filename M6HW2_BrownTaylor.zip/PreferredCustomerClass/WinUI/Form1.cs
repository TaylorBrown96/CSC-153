﻿/**
* 02May22
* CSC 153
* Taylor J. Brown
* Takes in user inputs and displays the created objects properties
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PreferredCustomerClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        // CustomerNum would be increased if I was taking in multiple customers and I needed to auto increment the customerNum as the primary key
        public int customerNum = 1;

        public Form1()
        {
            InitializeComponent();
            // Auto assigns the customerNum in the textbox 
            TB_customerNumberInput.Text = customerNum.ToString();
        }
        

        private void BT_Create_Click_1(object sender, EventArgs e)
        {
            // First way
            // Collects the user's inputs & assigns them to a variable 
            string name = TB_nameInput.Text;
            string address = TB_addressInput.Text;
            string phone = TB_phoneNumberInput.Text;
            int customerNumber = Convert.ToInt32(TB_customerNumberInput.Text);
            bool mailingList = CB_Agree.Checked;

            decimal cumulativePurchase;
            try
            {
                cumulativePurchase = Convert.ToDecimal(TB_totalSpentInput.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid dollar amount!","Error!");
                return;
            }

            int tier = PreferredCustomer.GetTier(cumulativePurchase);

            // Then creates the objects from the variables
            PreferredCustomer customer = new PreferredCustomer(name, address, phone, customerNumber, mailingList, cumulativePurchase, tier);

            // Second way 
            // Pulls in the users inputs directly into the object creation to save on memory usage
            /*
            Customer customer = new Customer(TB_nameInput.Text, TB_addressInput.Text, TB_phoneNumberInput.Text, Convert.ToInt32(TB_customerNumberInput.Text), CB_Agree.Checked);
            */

            // Updates the output textboxes
            TB_nameOutput.Text = customer.Name;
            TB_addressOutput.Text = customer.Address;
            TB_phoneOutput.Text = customer.PhoneNumber;
            TB_customerNumberOutput.Text = Convert.ToString(customer.CustomerNumber);
            TB_totalSpentOutput.Text = customer.CumulativePurchases.ToString("C");

            switch (customer.DiscountTier)
            {
                case 1:
                    TB_tierOutput.Text = "5%";
                    break;
                case 2:
                    TB_tierOutput.Text = "6%";
                    break;
                case 3:
                    TB_tierOutput.Text = "7%";
                    break;
                case 4:
                    TB_tierOutput.Text = "10%";
                    break;
                default:
                    TB_tierOutput.Text = "NONE";
                    break;
            }

            // Checks if the user agreed to the mailing list or not
            if (!customer.MailingList)
            {
                TB_mailingListOutput.Text = "False";
            }
            else
            {
                TB_mailingListOutput.Text = "True";
            }

            // Auto incrementing for customerNum 
            /*
            customerNum++;
            TB_customerNumberInput.Text = customerNum.ToString();
            */
        }


        // Closes the program
        private void BT_Exit_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
