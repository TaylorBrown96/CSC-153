﻿/**
* 02May22
* CSC 153
* Taylor J. Brown
* Takes in user inputs and displays the created objects properties
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class PreferredCustomer : Customer
    {
        public PreferredCustomer(string name, string address, string phoneNumber, int customerNumber, bool mailingList, decimal cumulativePurchases, int discountTier) : base(name, address, phoneNumber, customerNumber, mailingList)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            CustomerNumber = customerNumber;
            MailingList = mailingList;
            CumulativePurchases = cumulativePurchases;
            DiscountTier = discountTier;
        }
        public decimal CumulativePurchases { get; set; }
        public int DiscountTier { get; set; }

        public static int GetTier(decimal cumulative)
        {
            if (cumulative >= 500 && cumulative <= 999)
            {
                return 1;
            }
            else if (cumulative >= 1000 && cumulative <= 1499)
            {
                return 2;
            }
            else if (cumulative >= 1500 && cumulative <= 1999)
            {
                return 3;
            }
            else if (cumulative >= 2000)
            {
                return 4;
            }
            else
            {
                return 0;
            }   
        }
    }
}
