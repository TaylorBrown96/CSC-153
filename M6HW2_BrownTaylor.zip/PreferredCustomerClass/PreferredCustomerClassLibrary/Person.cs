﻿/**
* 02May22
* CSC 153
* Taylor J. Brown
* Takes in user inputs and displays the created objects properties
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    // Person is the parent class and the customer is the child class
    public class Person
    {
        public Person(string name, string address, string phoneNumber)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
        }

        public string Name { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
    }
}
