﻿/**
* 03MAR22
* CSC 153
* Taylor J. Brown
* This class takes in the wholesale cost of an item and its markup 
*   percentage and returns the suggested retail price.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceCalculatorLibrary
{
    public static class Calculate
    {
        public static decimal CalculateRetail(decimal wholesale_cost, decimal markup_percentage)
        {
            // Takes in the markup percentage and converts the whole percent to a value of 0.0-1.0 or greater.
            markup_percentage /= 100;

            // Multiplys the wholesale cost and new markup percentage together to get the mark up amount
            //  then adds the two values together to get the suggested retail price.
            decimal tmp = wholesale_cost * markup_percentage;
            decimal retail_price = wholesale_cost + tmp;

            return retail_price;
        }
    }
}
