﻿/**
* 03MAR22
* CSC 153
* Taylor J. Brown
* This program takes in the wholesale cost of an item and its markup 
*   percentage and presents the user with the suggested retail price.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceCalculatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void B_Calculate_Click(object sender, EventArgs e)
        {
            decimal wholesale_cost = 0.0m;
            decimal markup_percentage = 0;
            // Takes in the wholesale cost of the item
            try
            {
                wholesale_cost = decimal.Parse(TB_Wholesale.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Enter in a Wholesale price!");
            }

            // Takes in the markup percentage
            try
            {
                markup_percentage = decimal.Parse(TB_Markup.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Enter in a percentage!");
            }

            // Sends the CalulateRetal method two arguments (wholesale_cost and markup_percentage)
            //  and sets the returned value to the retail price variable.
            decimal retail_price = Calculate.CalculateRetail(wholesale_cost, markup_percentage);
            TB_Retail.Text = retail_price.ToString("C");
        }
    }
}
